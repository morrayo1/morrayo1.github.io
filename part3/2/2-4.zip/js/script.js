$(document).ready(function(){
	
	//반복문
	

	
	// for 문
	// for(초기값;조건;증감){조건이 틀릴때 까지 실행}
	
	for(var i=0; i<10; i++){
		
		for(var j=0; j<i; j++){
			document.write(' ');
		};
		
		document.write(i);
		document.write('<br />');
	}
	
	
})